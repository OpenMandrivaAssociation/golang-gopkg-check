Instructions
============

Install the package with:

    go get gopkg.in/check.v1
    
Import it with:

    import "gopkg.in/check.v1"

and use _check_ as the package name inside the code.

For more details, visit the project page:

* http://labix.org/gocheck

and the API documentation:

* https://gopkg.in/check.v1
